chrome.runtime.onMessage.addListener(function (request) {
    const { url } = request;
    if (request.message === 'urlChanged' && url.indexOf('sold_items') > -1) {
        location.href = url;
    }

});

window.onload = function () {

    'use strict';

    if (location.search.length > 0 && location.search.indexOf('dataFilterUsed') === -1) {
        location.href = location.origin + location.pathname;
    }
    else {

        let loadMoreBtn = document.getElementById('load-more');
        let table = document.getElementById('sold-items-table-body');
        let minDate = document.getElementById('date_min');
        let maxDate = document.getElementById('date_max');
        let filterBtn = document.getElementsByClassName('button')[1];
        let deleteFilterBtn = document.getElementById('clear-filters-button');


        if (table) {

            let topMengeEbook = document.getElementsByClassName('top-menge-ebook');
            let topMenge = document.getElementsByClassName('top-menge');
            let topAuszEbook = document.getElementsByClassName('top-ausz-ebook');
            let topAusz = document.getElementsByClassName('top-ausz');
            let rows = table.getElementsByTagName('tr');
            let orderData = {
                totalBestellungen: 0,
                totalOrders: 0,
                totalNetto: 0,
                totalBrutto: 0,
                orders: [],
                top5Menge: [],
                top5Auszahlung: []
            }
            let topListe = {};
            let chart;

            let loadMore;

            elementUebersicht();
            changeTableLinks();

            loadData();

            function loadData() {
                loadMore = setInterval(function () {
                    if (loadMoreBtn.style.display !== 'none') {
                        loadMoreBtn.click();
                    }
                    else {
                        clearInterval(loadMore);
                        initApplication();
                    }
                }
                    , 300)
            }

            function initApplication() {
                resetOrderData();

                if(chart) {
                    chart.destroy();
                }

                getOrderData();
                getTop5Liste();
                getTop5ListeAuszahlung();
                setUebersichtText();
            }

            function resetOrderData() {
                orderData = {
                    totalBestellungen: 0,
                    totalOrders: 0,
                    totalNetto: 0,
                    totalBrutto: 0,
                    orders: [],
                    top5Menge: [],
                    top5Auszahlung: []
                }
            }

            function getOrderData() {
                for (let i = 0; i < rows.length; i++) {
                    let row = rows[i];
                    getOrderDataByRow(row);
                }
            }

            function getOrderDataByRow(row) {
                let netto = convertStringToFloat(row.children[3].textContent);
                let brutto = convertStringToFloat(row.children[4].textContent);
                let einzelVerkauf = parseInt(row.children[2].textContent);
                let orderDate = parseDate(row.children[0].textContent);
                let order = {
                    datum: orderDate,
                    ebookName: row.querySelector('a').getAttribute('title').trim(),
                    menge: einzelVerkauf,
                    nettoAuszahlung: netto,
                    bruttoAuszahlung: brutto,
                }
                orderData.orders.push(order);
                orderData.totalOrders++;
                orderData.totalNetto += netto;
                orderData.totalBrutto += brutto;
                orderData.totalBestellungen += einzelVerkauf;
                getTopListe(order);
            }

            function getTopListe(order) {
                if (topListe.hasOwnProperty(order.ebookName)) {
                    topListe[order.ebookName].menge += order.menge;
                        topListe[order.ebookName].nettoAuszahlung += order.nettoAuszahlung;
                        topListe[order.ebookName].bruttoAuszahlung += order.bruttoAuszahlung;
                }
                else {
                    topListe[order.ebookName] = {
                        menge: order.menge,
                        nettoAuszahlung: order.nettoAuszahlung,
                        bruttoAuszahlung: order.bruttoAuszahlung,
                        name: order.ebookName,
                    }
                }
            }

            function getTop5Liste() {
                let objectsTopListe = Object.keys(topListe);
                for (let i = 0; i < objectsTopListe.length; i++) {
                    let objectTopListe = topListe[objectsTopListe[i]];
                    orderData.top5Menge.push(objectTopListe);
                }
                orderData.top5Menge.sort(function (a, b) {
                    return b.menge - a.menge;
                })
            }

            function getTop5ListeAuszahlung() {
                let objectsTopListe = Object.keys(topListe);
                for (let i = 0; i < objectsTopListe.length; i++) {
                    let objectTopListe = topListe[objectsTopListe[i]];
                    orderData.top5Auszahlung.push(objectTopListe);
                }
                orderData.top5Auszahlung.sort(function (a, b) {
                    return b.nettoAuszahlung - a.nettoAuszahlung;
                })
            }

            function convertStringToFloat(moneystring) {
                moneystring = moneystring.replace(',', '.');
                moneystring = moneystring.replace('€', '');
                return parseFloat(moneystring);
            }

            function parseDate(input) {
                const parts = input.match(/(\d+)/g);
                // note parts[1]-1
                return new Date(parts[2], parts[1] - 1, parts[0]);
            }

            function elementUebersicht() {

                let insightsWrapper = document.createElement('div');
                let auszahlungWrapper = document.createElement('div');
                let top5MengeWrapper = document.createElement('div');
                let top5AuszahlungsWrapper = document.createElement('div');

                insightsWrapper.classList.add('insights-wrapper');
                auszahlungWrapper.classList.add('d-flex-33', 'table-header');
                top5MengeWrapper.classList.add('d-flex-33', 'table-header');
                top5AuszahlungsWrapper.classList.add('d-flex-33', 'table-header');

                let posHeading1 = document.getElementsByClassName('sold-items-container')[0];
                let posHeading2 = document.getElementsByClassName('table-header')[1];
                posHeading1.insertBefore(insightsWrapper, posHeading2);

                insightsWrapper.appendChild(auszahlungWrapper);
                insightsWrapper.appendChild(top5MengeWrapper);
                insightsWrapper.appendChild(top5AuszahlungsWrapper);

                let hAuszahlung = document.createElement('h2');
                let hTop5Menge = document.createElement('h2');
                let hTop5Auszahlung = document.createElement('h2');

                let hAuszahlungText = document.createTextNode('Auszahlungen');
                hAuszahlung.appendChild(hAuszahlungText);

                let hTop5MengeText = document.createTextNode('Top 5 - nach Menge');
                hTop5Menge.appendChild(hTop5MengeText);

                let hTop5AuszahlungText = document.createTextNode('Top 5 - nach Netto-Auszahlung');
                hTop5Auszahlung.appendChild(hTop5AuszahlungText);

                let blockAuszahlung = document.createElement('div');
                let blockTop5Menge = document.createElement('div');
                let blockTop5Auszahlung = document.createElement('div');

                blockAuszahlung.classList.add('insights-block', 'insights-block--flex');
                blockTop5Menge.classList.add('insights-block');
                blockTop5Auszahlung.classList.add('insights-block');

                blockAuszahlung.innerHTML = "<p class='block-p'><span id='netto-summe' class='block-summe'>Lädt...</span>Summe Netto</p><p class='block-p'><span id='brutto-summe' class='block-summe'>Lädt...</span>Summe Brutto</p>";
                blockTop5Menge.innerHTML =
                    '<div class="inline-div"><span class="top-menge-ebook ellipsis">Wird geladen</span><span class="top-menge bold-number"><span></span></div><div class="inline-div"><span class="top-menge-ebook ellipsis">Wird geladen</span><span class="top-menge bold-number"><span></span></div><div class="inline-div"><span class="top-menge-ebook ellipsis">Wird geladen</span><span class="top-menge bold-number"><span></span></div><div class="inline-div"><span class="top-menge-ebook ellipsis">Wird geladen</span><span class="top-menge bold-number"><span></span></div><div class="inline-div"><span class="top-menge-ebook ellipsis">Wird geladen</span><span class="top-menge bold-number"><span></span></div>'
                blockTop5Auszahlung.innerHTML =
                    '<div class="inline-div"><span class="top-ausz-ebook ellipsis">Wird geladen</span><span class="top-ausz bold-number"><span></span></div><div class="inline-div"><span class="top-ausz-ebook ellipsis">Wird geladen</span><span class="top-ausz bold-number"><span></span></div><div class="inline-div"><span class="top-ausz-ebook ellipsis">Wird geladen</span><span class="top-ausz bold-number"><span></span></div><div class="inline-div"><span class="top-ausz-ebook ellipsis">Wird geladen</span><span class="top-ausz bold-number"><span></span></div><div class="inline-div"><span class="top-ausz-ebook ellipsis">Wird geladen</span><span class="top-ausz bold-number"><span></span></div>'

                auszahlungWrapper.appendChild(hAuszahlung);
                auszahlungWrapper.appendChild(blockAuszahlung);
                top5MengeWrapper.appendChild(hTop5Menge);
                top5MengeWrapper.appendChild(blockTop5Menge);
                top5AuszahlungsWrapper.appendChild(hTop5Auszahlung);
                top5AuszahlungsWrapper.appendChild(blockTop5Auszahlung);

                let chartWrapper = document.createElement('div')
                chartWrapper.setAttribute('id', 'chart-wrapper')
                chartWrapper.setAttribute('class', 'table-header')
                posHeading1.insertBefore(chartWrapper, posHeading2);

                chartWrapper.innerHTML = '<div class="mi-chart-header"><h2>Verkäufe im Zeitverlauf</h2></div><div class="canvas-wrapper"><canvas id="chart-canvas"></canvas></div>'
            }

            function setUebersichtText() {

                let nettoText = document.getElementById('netto-summe');
                nettoText.textContent = orderData.totalNetto.toFixed(2) + ' €';

                let bruttoText = document.getElementById('brutto-summe');
                bruttoText.textContent = orderData.totalBrutto.toFixed(2) + ' €';

                for (let i = 0; i < 5; i++) {
                    if (orderData.top5Menge[i]) {
                        topMengeEbook[i].textContent = i + 1 + '. ' + orderData.top5Menge[i].name;
                        topMenge[i].textContent = orderData.top5Menge[i].menge;
                    }

                    if (orderData.top5Auszahlung[i]) {
                        topAuszEbook[i].textContent = i + 1 + '. ' + orderData.top5Auszahlung[i].name;
                        topAusz[i].textContent = orderData.top5Auszahlung[i].nettoAuszahlung.toFixed(2) + ' €';
                    }
                }

                chart = renderChart(orderData.orders, '#chart-canvas', minDate.value, maxDate.value, 'nettoAuszahlung');
            }


            deleteFilterBtn.onclick = function (event) {
                event.preventDefault();
                location.href = location.origin + location.pathname;
            }

            filterBtn.onclick = function () {
                if (document.getElementById('date_min').value) {
                    clearArray();
                    clearTopListe();
                    clearUebersichtText();
                    chart.destroy();
                    setTimeout(loadData, 2000);
                }
            }

            function clearArray() {
                orderData = {
                    totalBestellungen: 0,
                    totalOrders: 0,
                    totalNetto: 0,
                    totalBrutto: 0,
                    orders: [],
                    top5Menge: [],
                    top5Auszahlung: []
                }
            }

            function clearTopListe() {
                topListe = {};
            }

            function clearUebersichtText() {
                for (let i = 0; i < 5; i++) {
                    topMengeEbook[i].textContent = '';
                    topMenge[i].textContent = '';
                    topAuszEbook[i].textContent = '';
                    topAusz[i].textContent = '';
                }
            }

            function changeTableLinks() {
                let links = document.querySelectorAll('th a');
                for (let i = 0; i < links.length; i++) {
                    let link = links[i];
                    let oldHref = link.getAttribute('href');
                    link.setAttribute('href', oldHref + '?dataFilterUsed')

                }
            }
        }
    }
}